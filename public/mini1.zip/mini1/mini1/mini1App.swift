//
//  mini1App.swift
//  mini1
//
//  Created by Gustavo Munhoz Correa on 21/06/23.
//

import SwiftUI

@main
struct mini1App: App {
    var body: some Scene {
        WindowGroup {
            StartView()
        }
    }
}
