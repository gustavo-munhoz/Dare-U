//
//  EditView.swift
//  mini1
//
//  Created by Yana Preisler on 28/06/23.
//

import SwiftUI

struct EditView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct EditView_Previews: PreviewProvider {
    static var previews: some View {
        EditView()
    }
}
