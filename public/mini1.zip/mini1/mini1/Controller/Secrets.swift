//
//  Secrets.swift
//  mini1
//
//  Created by Gustavo Munhoz Correa on 05/07/23.
//

import Foundation

class Secrets {
    static let CHATGPT_API_KEY = "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"
}
